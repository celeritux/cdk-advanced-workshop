import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "celeritux.jsii.multi-region-s3-crr-kms-cmk-source",
    "version": "0.1.0",
    "description": "multi-region-s3-crr-kms-cmk-source",
    "license": "MIT",
    "url": "https://github.com/celeritux/multi-region-s3-crr-kms-cmk-source.git",
    "long_description_content_type": "text/markdown",
    "author": "Fabrizio Vigato<test-email@false.com>",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/celeritux/multi-region-s3-crr-kms-cmk-source.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "celeritux.jsii.multi-region-s3-crr-kms-cmk-source",
        "celeritux.jsii.multi-region-s3-crr-kms-cmk-source._jsii"
    ],
    "package_data": {
        "celeritux.jsii.multi-region-s3-crr-kms-cmk-source._jsii": [
            "multi-region-s3-crr-kms-cmk-source@0.1.0.jsii.tgz"
        ],
        "celeritux.jsii.multi-region-s3-crr-kms-cmk-source": [
            "py.typed"
        ]
    },
    "python_requires": ">=3.6",
    "install_requires": [
        "aws-cdk-lib==2.3.0",
        "constructs>=10.0.0, <11.0.0",
        "jsii>=1.49.0, <2.0.0",
        "publication>=0.0.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Typing :: Typed",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
