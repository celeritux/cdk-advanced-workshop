import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import aws_cdk._jsii
import constructs._jsii

__jsii_assembly__ = jsii.JSIIAssembly.load(
    "multi-region-s3-crr-kms-cmk-source",
    "0.1.0",
    __name__[0:-6],
    "multi-region-s3-crr-kms-cmk-source@0.1.0.jsii.tgz",
)

__all__ = [
    "__jsii_assembly__",
]

publication.publish()
